FINDS — STATIC PROTOTYPE

Preview: http://127.0.0.1:18765/ while the local preview server is running. To start one from this folder, run:

  python -m http.server 18765

The project is plain HTML, CSS and lightweight JavaScript. It needs no framework, database, accounts or build step.

EDIT CONTENT
- data.js is the single hand-editable file for the brand, styles, shops and products.
- The sample contains 3 fictional shops and 12 products (FN-001–FN-012).
- Each product has an editable primary and alternate illustration path; replace both with seller-provided images when available.
- Product conditions are Like new, Good or Worn. Styles belong to products only.
- Shop logos, covers and product image paths are listed in data.js and stored under /images.
- finds-logo-blue.svg and finds-logo-blue-deep.svg are used unchanged. The dark and light versions swap according to the saved theme.
- The order number remains intentionally blank. Add the real Egyptian WhatsApp number as digits only, beginning with 20, to activate orders. Sold products remain visible and non-orderable.

DESIGN AND FONTS
- The default palette is charcoal, cream and blue, with a persistent light theme (localStorage key: finds-theme).
- The display font is Bebas Neue, with the locally hosted Inter and Cairo fallbacks. Inter is licensed under the SIL Open Font License in fonts/OFL.txt.
- The samples are original replaceable SVG illustrations, not seller photographs. Alternate views mirror each sample illustration until sellers supply real images.
- Animations use CSS transforms and opacity, respect reduced-motion preferences and are minimized on phones.

PAGES AND FEATURES
- Home, Shops, shop, style, product, Policy and Settings routes remain in place.
- The style strip stays horizontally swipeable and draggable. Style pages aggregate matching products, available first and sold last.
- Product ordering remains disabled until the real WhatsApp number is configured.
- Each shop page retains the sample seller Instagram contact and complaints link at the bottom.
