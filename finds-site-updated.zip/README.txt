FINDS — STATIC PROTOTYPE

Open the preview at http://127.0.0.1:18765/ while the local preview server is running. To start a server from this folder, run:

  python -m http.server 18765

Then open http://127.0.0.1:18765/ in a browser. The project is plain HTML, CSS and lightweight JavaScript; it needs no framework, build step, account, database or external image service.

EDIT CONTENT
- data.js is the single hand-editable file for the brand, styles, shops and products.
- The demo has 3 fictional shops and 12 products (FN-001–FN-012). Add a product by adding one object to products and selecting its shop ID.
- Product conditions are Like new, Good or Worn. Styles belong to products only.
- Replace a shop's logo or cover by replacing its named file in /images or changing the matching filename in data.js. Product image paths are listed next to each product.
- The supplied images/finds-logo-blue.svg and finds-logo-blue-deep.svg are included unchanged. The transparent black hero variant is images/finds-logo-dark.svg.
- The sample WhatsApp number is intentionally blank. Add the real Egyptian number as digits only, beginning with 20, to activate ordering. Sold products remain visible and non-orderable.

DESIGN AND FONTS
- Yellow accent: #F0B014. The site defaults to a true-black dark theme and offers a persistent light theme through the sidebar toggle (localStorage key: finds-theme).
- Sidebar and footer logos swap between the supplied blue (#72A0C1) and deep blue (#427397) SVGs; the hero uses a transparent near-black vector treatment.
- The live OBEY site uses GT America. That commercial webfont requires a webfont license; no licensed GT America file was included or installed on this PC. This prototype self-hosts Inter, an open font under the SIL Open Font License, as a close UI-type substitute. The license is in fonts/OFL.txt.
- The homepage cover is a CSS collage with grain because no separate cover photo was supplied. Shop and product illustrations are replaceable SVG placeholders in /images.

REFERENCE INFLUENCE
The thin ticker, uppercase product-card hierarchy, small size row and grouped footer take cues from OBEY. The Finds page structure, logo, sample content and yellow-and-black identity are kept original.
