/*
  FINDS CONTENT — edit this file to change all replaceable site content.
  Keep product IDs unique (FN-001 through FN-012 for the sample set).
  Add or replace image files in /images and update the matching filename below.
  Styles belong to products, never shops. Use Like new, Good, or Worn.
  Set whatsappNumber to a real Egyptian international number (digits only,
  starting with 20) to activate the Order links. It is intentionally blank.
*/
window.FINDS_DATA = {
  brand: 'finds',
  logoImage: 'images/finds-logo-blue.svg',
  lightLogoImage: 'images/finds-logo-blue-deep.svg',
  tagline: 'Your style. All in one place.',
  policyEmail: '[email]',
  whatsappNumber: '',
  styles: ['Y2K', 'Grunge', 'Coquette', 'Streetwear', '90s Vintage', 'Old Money'],
  shops: [
    {
      id: 'velvet-loop',
      name: 'The Velvet Loop',
      description: 'Secondhand statements with a little sparkle.',
      logo: 'images/shop-velvet-loop-logo.svg',
      cover: 'images/shop-velvet-loop-cover.svg',
      instagram: 'seller_username'
    },
    {
      id: 'cobalt-club',
      name: 'Cobalt Club',
      description: 'Easy streetwear for your everyday rotation.',
      logo: 'images/shop-cobalt-club-logo.svg',
      cover: 'images/shop-cobalt-club-cover.svg',
      instagram: 'seller_username'
    },
    {
      id: 'sunday-elsewhere',
      name: 'Sunday Elsewhere',
      description: 'Soft vintage pieces for slower days.',
      logo: 'images/shop-sunday-elsewhere-logo.svg',
      cover: 'images/shop-sunday-elsewhere-cover.svg',
      instagram: 'seller_username'
    }
  ],
  products: [
    { id: 'FN-001', name: 'Cherry Soda Slip Skirt', price: 780, size: 'M', condition: 'Good', style: 'Y2K', status: 'available', shop: 'velvet-loop', image: 'images/product-fn-001.svg', alternateImage: 'images/product-alt-fn-001.svg' },
    { id: 'FN-002', name: 'After Hours Mesh Top', price: 620, size: 'S', condition: 'Like new', style: 'Grunge', status: 'available', shop: 'velvet-loop', image: 'images/product-fn-002.svg', alternateImage: 'images/product-alt-fn-002.svg' },
    { id: 'FN-003', name: 'Ribbon Daydream Blouse', price: 890, size: 'M', condition: 'Good', style: 'Coquette', status: 'sold', shop: 'velvet-loop', image: 'images/product-fn-003.svg', alternateImage: 'images/product-alt-fn-003.svg' },
    { id: 'FN-004', name: 'Velvet Night Mini Dress', price: 1150, size: 'S', condition: 'Good', style: '90s Vintage', status: 'available', shop: 'velvet-loop', image: 'images/product-fn-004.svg', alternateImage: 'images/product-alt-fn-004.svg' },

    { id: 'FN-005', name: 'Metro Zip Hoodie', price: 980, size: 'L', condition: 'Good', style: 'Streetwear', status: 'available', shop: 'cobalt-club', image: 'images/product-fn-005.svg', alternateImage: 'images/product-alt-fn-005.svg' },
    { id: 'FN-006', name: 'Cargo Crush Trousers', price: 1080, size: 'M', condition: 'Like new', style: 'Y2K', status: 'available', shop: 'cobalt-club', image: 'images/product-fn-006.svg', alternateImage: 'images/product-alt-fn-006.svg' },
    { id: 'FN-007', name: 'Skatepark Graphic Tee', price: 520, size: 'M', condition: 'Good', style: 'Grunge', status: 'sold', shop: 'cobalt-club', image: 'images/product-fn-007.svg', alternateImage: 'images/product-alt-fn-007.svg' },
    { id: 'FN-008', name: 'Blue Hour Denim', price: 920, size: 'S', condition: 'Good', style: '90s Vintage', status: 'available', shop: 'cobalt-club', image: 'images/product-fn-008.svg', alternateImage: 'images/product-alt-fn-008.svg' },

    { id: 'FN-009', name: 'Sunday Cotton Shirt', price: 840, size: 'M', condition: 'Like new', style: 'Old Money', status: 'available', shop: 'sunday-elsewhere', image: 'images/product-fn-009.svg', alternateImage: 'images/product-alt-fn-009.svg' },
    { id: 'FN-010', name: 'Garden Party Dress', price: 1250, size: 'S', condition: 'Good', style: 'Coquette', status: 'available', shop: 'sunday-elsewhere', image: 'images/product-fn-010.svg', alternateImage: 'images/product-alt-fn-010.svg' },
    { id: 'FN-011', name: 'Sunday Best Knit', price: 760, size: 'L', condition: 'Good', style: 'Old Money', status: 'available', shop: 'sunday-elsewhere', image: 'images/product-fn-011.svg', alternateImage: 'images/product-alt-fn-011.svg' },
    { id: 'FN-012', name: 'Soft Focus Blazer', price: 1380, size: 'M', condition: 'Good', style: 'Old Money', status: 'sold', shop: 'sunday-elsewhere', image: 'images/product-fn-012.svg', alternateImage: 'images/product-alt-fn-012.svg' }
  ]
};
