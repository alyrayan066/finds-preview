/*
  FINDS CONTENT — edit this file to change all replaceable site content.
  Keep product IDs unique (FN-001 through FN-012 for the sample set).
  Add or replace image files in /images and update the matching filename below.
  Styles belong to products, never shops. Use Like new, Good, or Worn.
  Set whatsappNumber to a real Egyptian international number (digits only,
  starting with 20) to activate the Order links. It is intentionally blank.
*/
window.FINDS_DATA = {
  brand: 'finds',
  logoImage: 'images/finds-logo-blue.svg',
  tagline: 'Your style. All in one place.',
  policyEmail: '[email]',
  whatsappNumber: '',
  styles: ['Grunge', 'Coquette', 'Streetwear', '90s Vintage', 'Old Money'],
  productTypes: ['Skirts', 'Tops', 'Blouses', 'Dresses', 'Hoodies', 'Trousers', 'T-shirts', 'Jeans', 'Shirts', 'Knitwear', 'Blazers'],
  shops: [
    {
      id: 'velvet-loop',
      name: 'The Velvet Loop',
      description: 'Secondhand statements with a little sparkle.',
      logo: 'images/shop-velvet-loop-logo.svg',
      cover: 'images/shop-velvet-loop-cover.svg',
      instagram: 'seller_username'
    },
    {
      id: 'cobalt-club',
      name: 'Cobalt Club',
      description: 'Easy streetwear for your everyday rotation.',
      logo: 'images/shop-cobalt-club-logo.svg',
      cover: 'images/shop-cobalt-club-cover.svg',
      instagram: 'seller_username'
    },
    {
      id: 'sunday-elsewhere',
      name: 'Sunday Elsewhere',
      description: 'Soft vintage pieces for slower days.',
      logo: 'images/shop-sunday-elsewhere-logo.svg',
      cover: 'images/shop-sunday-elsewhere-cover.svg',
      instagram: 'seller_username'
    }
  ],
  products: [
    { id: 'FN-001', name: 'Cherry Soda Slip Skirt', price: 780, size: 'M', condition: 'Good', itemType: 'Skirts', status: 'available', shop: 'velvet-loop', image: 'images/product-fn-001.svg', alternateImage: 'images/product-alt-fn-001.svg' },
    { id: 'FN-002', name: 'After Hours Mesh Top', price: 620, size: 'S', condition: 'Like new', style: 'Grunge', itemType: 'Tops', status: 'available', shop: 'velvet-loop', image: 'images/product-fn-002.svg', alternateImage: 'images/product-alt-fn-002.svg' },
    { id: 'FN-003', name: 'Ribbon Daydream Blouse', price: 890, size: 'M', condition: 'Good', style: 'Coquette', itemType: 'Blouses', status: 'sold', shop: 'velvet-loop', image: 'images/product-fn-003.svg', alternateImage: 'images/product-alt-fn-003.svg' },
    { id: 'FN-004', name: 'Velvet Night Mini Dress', price: 1150, size: 'S', condition: 'Good', style: '90s Vintage', itemType: 'Dresses', status: 'available', shop: 'velvet-loop', image: 'images/product-fn-004.svg', alternateImage: 'images/product-alt-fn-004.svg' },

    { id: 'FN-005', name: 'Metro Zip Hoodie', price: 980, size: 'L', condition: 'Good', style: 'Streetwear', itemType: 'Hoodies', status: 'available', shop: 'cobalt-club', image: 'images/product-fn-005.svg', alternateImage: 'images/product-alt-fn-005.svg' },
    { id: 'FN-006', name: 'Cargo Crush Trousers', price: 1080, size: 'M', condition: 'Like new', itemType: 'Trousers', status: 'available', shop: 'cobalt-club', image: 'images/product-fn-006.svg', alternateImage: 'images/product-alt-fn-006.svg' },
    { id: 'FN-007', name: 'Skatepark Graphic Tee', price: 520, size: 'M', condition: 'Good', style: 'Grunge', itemType: 'T-shirts', status: 'sold', shop: 'cobalt-club', image: 'images/product-fn-007.svg', alternateImage: 'images/product-alt-fn-007.svg' },
    { id: 'FN-008', name: 'Blue Hour Denim', price: 920, size: 'S', condition: 'Good', style: '90s Vintage', itemType: 'Jeans', status: 'available', shop: 'cobalt-club', image: 'images/product-fn-008.svg', alternateImage: 'images/product-alt-fn-008.svg' },

    { id: 'FN-009', name: 'Sunday Cotton Shirt', price: 840, size: 'M', condition: 'Like new', style: 'Old Money', itemType: 'Shirts', status: 'available', shop: 'sunday-elsewhere', image: 'images/product-fn-009.svg', alternateImage: 'images/product-alt-fn-009.svg' },
    { id: 'FN-010', name: 'Garden Party Dress', price: 1250, size: 'S', condition: 'Good', style: 'Coquette', itemType: 'Dresses', status: 'available', shop: 'sunday-elsewhere', image: 'images/product-fn-010.svg', alternateImage: 'images/product-alt-fn-010.svg' },
    { id: 'FN-011', name: 'Sunday Best Knit', price: 760, size: 'L', condition: 'Good', style: 'Old Money', itemType: 'Knitwear', status: 'available', shop: 'sunday-elsewhere', image: 'images/product-fn-011.svg', alternateImage: 'images/product-alt-fn-011.svg' },
    { id: 'FN-012', name: 'Soft Focus Blazer', price: 1380, size: 'M', condition: 'Good', style: 'Old Money', itemType: 'Blazers', status: 'sold', shop: 'sunday-elsewhere', image: 'images/product-fn-012.svg', alternateImage: 'images/product-alt-fn-012.svg' }
  ]
};
