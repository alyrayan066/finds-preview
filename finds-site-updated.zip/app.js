(() => {
  'use strict';

  const data = window.FINDS_DATA;
  const root = document.getElementById('page-content');
  const menu = document.getElementById('site-menu');
  const scrim = document.getElementById('menu-scrim');
  const menuToggle = document.getElementById('menu-toggle');
  const drawerClose = document.getElementById('drawer-close');
  const sidebarToggle = document.getElementById('sidebar-collapse-toggle');
  const themeButton = document.getElementById('theme-toggle');
  const themeMeta = document.querySelector('meta[name="theme-color"]');
  const tickerPhrases = [
    'GOOD CLOTHES, FOUND AGAIN',
    'EGYPTIAN SELLERS, EGYPTIAN STYLE',
    'ONE OF A KIND'
  ];
  const money = value => `EGP ${Number(value).toLocaleString('en-US')}`;
  const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
  const slug = value => String(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const shopFor = id => data.shops.find(shop => shop.id === id);
  const productsFor = id => data.products.filter(product => product.shop === id);
  const stylePath = style => `#/style/${encodeURIComponent(slug(style))}`;

  function image(src, alt, className = '', eager = false) {
    return `<img class="${className}" src="${escapeHTML(src)}?v=refined-20261122" alt="${escapeHTML(alt)}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async">`;
  }

  function styleStrip(active = '') {
    return `<nav class="style-strip" aria-label="Browse by style">
      <span class="strip-label">SHOP BY STYLE</span>
      <div class="style-track" id="style-track">${data.styles.map(style =>
        `<a class="style-chip${active === style ? ' is-active' : ''}" href="${stylePath(style)}"${active === style ? ' aria-current="page"' : ''}>${escapeHTML(style)}<span aria-hidden="true">↗</span></a>`
      ).join('')}</div>
    </nav>`;
  }

  function productCard(product) {
    const shop = shopFor(product.shop);
    const sold = product.status === 'sold';
    const alternate = product.alternateImage
      ? image(product.alternateImage, `${product.name} alternate view`, 'product-image product-image-alt')
      : '';
    return `<article class="product-card${sold ? ' is-sold' : ''}">
      <a class="product-image-link" href="#/product/${encodeURIComponent(product.id)}" aria-label="View ${escapeHTML(product.name)}">
        ${image(product.image, product.name, 'product-image product-image-primary')}${alternate}
        ${product.style ? `<span class="product-style">${escapeHTML(product.style)}</span>` : ''}
        <span class="product-id">${escapeHTML(product.id)}</span>
        ${sold ? '<span class="sold-stamp">SOLD</span>' : ''}
      </a>
      <div class="product-card-copy">
        <div class="product-title-row">
          <a class="product-name" href="#/product/${encodeURIComponent(product.id)}">${escapeHTML(product.name)}</a>
          <span class="product-price">${money(product.price)}</span>
        </div>
        <div class="product-size-row"><span>SIZE <b>${escapeHTML(product.size)}</b></span><a href="#/shop/${encodeURIComponent(shop.id)}">${escapeHTML(shop.name)}</a></div>
      </div>
    </article>`;
  }

  function shopCard(shop, index) {
    const count = productsFor(shop.id).length;
    return `<article class="shop-card">
      <a class="shop-cover-link" href="#/shop/${encodeURIComponent(shop.id)}" aria-label="Visit ${escapeHTML(shop.name)}">
        ${image(shop.cover, `${shop.name} sample cover`, 'shop-cover')}
        <span class="cover-label">SAMPLE SHOP · 0${index + 1}</span>
      </a>
      <div class="shop-card-body">
        ${image(shop.logo, `${shop.name} placeholder logo`, 'shop-avatar')}
        <div class="shop-summary"><a class="shop-name" href="#/shop/${encodeURIComponent(shop.id)}">${escapeHTML(shop.name)}</a><p>${escapeHTML(shop.description)}</p></div>
        <span class="shop-count"><b>${String(count).padStart(2, '0')}</b><small>PIECES</small></span>
      </div>
    </article>`;
  }

  function homePage() {
    const darkLogo = escapeHTML(data.logoImage);
    const lightLogo = escapeHTML(data.lightLogoImage);
    return `<section class="home-hero" aria-labelledby="home-title">
      <div class="hero-collage" aria-hidden="true"><div class="hero-panel"></div><div class="hero-frame"></div><i>✦</i></div>
      <div class="hero-content">
        <span class="hero-logo logo-swap" role="img" aria-label="finds logo"><img class="logo-dark" src="${darkLogo}" alt=""><img class="logo-light" src="${lightLogo}" alt=""></span>
        <div class="hero-copy">
          <h1 id="home-title" class="hero-tagline">${escapeHTML(data.tagline)}</h1>
          <a class="hero-link" href="#/shops">EXPLORE THE SHOPS <span aria-hidden="true">↗</span></a>
        </div>
      </div>
    </section>
    ${styleStrip()}
    <section class="content-section shop-section" aria-labelledby="shops-title">
      <div class="section-heading">
        <div><h2 id="shops-title">MEET THE <span>SHOPS</span></h2></div>
        <a class="text-link" href="#/shops">ALL SHOPS <b aria-hidden="true">↗</b></a>
      </div>
      <div class="shop-grid">${data.shops.map((shop, index) => shopCard(shop, index)).join('')}</div>
    </section>`;
  }

  function shopsPage() {
    return `<section class="page-intro"><h1>MEET THE <span>SHOPS</span></h1><p>Independent Egyptian sellers with wardrobes worth a second look.</p></section>
      <div class="shop-grid shop-grid-page">${data.shops.map((shop, index) => shopCard(shop, index)).join('')}</div>`;
  }

  function stylePage(styleSlug) {
    const style = data.styles.find(item => slug(item) === styleSlug);
    if (!style) return notFound();
    const products = data.products.filter(product => product.style === style)
      .sort((a, b) => Number(a.status === 'sold') - Number(b.status === 'sold'));
    return `${styleStrip(style)}<section class="page-intro style-intro"><p class="eyebrow">THE STYLE EDIT · ${products.length} PIECES</p><h1>${escapeHTML(style)} <span>FINDS</span></h1><p>Pieces from every shop, gathered by style. Available finds come first.</p></section>
      <div class="product-grid">${products.map(productCard).join('')}</div>`;
  }

  function shopPage(id) {
    const shop = shopFor(id);
    if (!shop) return notFound();
    const products = productsFor(id)
      .sort((a, b) => Number(a.status === 'sold') - Number(b.status === 'sold'));
    return `<section class="storefront">
      <div class="store-cover-wrap">${image(shop.cover, `${shop.name} cover`, 'store-cover', true)}<span class="store-cover-sticker">SAMPLE COVER ✦</span></div>
      <div class="store-heading">${image(shop.logo, `${shop.name} placeholder logo`, 'store-logo')}<div><p class="eyebrow">INDEPENDENT SELLER</p><h1>${escapeHTML(shop.name)}</h1><p class="store-description">${escapeHTML(shop.description)}</p></div></div>
      <div class="store-products-head"><h2>THE COLLECTION <span>(${products.length})</span></h2><span>AVAILABLE AND SOLD</span></div>
      <div class="product-grid">${products.map(productCard).join('')}</div>
      <footer class="store-contact"><a href="https://www.instagram.com/${encodeURIComponent(shop.instagram)}" target="_blank" rel="noopener noreferrer">INSTAGRAM @${escapeHTML(shop.instagram)} <span aria-hidden="true">↗</span></a></footer>
    </section>`;
  }

  function productPage(id) {
    const product = data.products.find(item => item.id === id);
    if (!product) return notFound();
    const shop = shopFor(product.shop);
    const sold = product.status === 'sold';
    const activeNumber = /^20\d{8,14}$/.test(String(data.whatsappNumber || ''));
    const orderMessage = encodeURIComponent(`Hi, I want piece #${product.id} from Finds`);
    const order = sold
      ? '<button class="order-button" type="button" disabled>SOLD · NOT AVAILABLE</button>'
      : activeNumber
        ? `<a class="order-button" href="https://wa.me/${encodeURIComponent(data.whatsappNumber)}?text=${orderMessage}" target="_blank" rel="noopener noreferrer">ORDER VIA WHATSAPP <span aria-hidden="true">↗</span></a>`
        : '<button class="order-button" type="button" disabled>ORDERING NOT SET UP YET</button><p class="order-note">Add the real Egyptian WhatsApp number (starting with 20) in data.js to enable orders.</p>';
    return `<a class="back-link" href="#/shop/${encodeURIComponent(shop.id)}">← BACK TO ${escapeHTML(shop.name)}</a>
      <section class="product-detail">
        <div class="detail-image-wrap">${image(product.image, product.name, 'detail-image', true)}${sold ? '<span class="sold-stamp detail-sold">SOLD</span>' : ''}</div>
        <div class="detail-copy"><p class="eyebrow">${sold ? 'FOUND ITS HOME' : 'ONE OF A KIND'}</p><p class="product-id">${escapeHTML(product.id)}</p><h1>${escapeHTML(product.name)}</h1><p class="detail-price">${money(product.price)}</p>
          <div class="status-pill${sold ? ' status-sold' : ''}"><span></span>${sold ? 'SOLD' : 'AVAILABLE'}</div>
          <dl class="product-facts"><div><dt>SIZE</dt><dd>${escapeHTML(product.size)}</dd></div><div><dt>CONDITION</dt><dd>${escapeHTML(product.condition)}</dd></div>${product.style ? `<div><dt>STYLE</dt><dd><a href="${stylePath(product.style)}">${escapeHTML(product.style)} ↗</a></dd></div>` : ''}<div><dt>SHOP</dt><dd><a href="#/shop/${encodeURIComponent(shop.id)}">${escapeHTML(shop.name)} ↗</a></dd></div><div><dt>PRODUCT ID</dt><dd>${escapeHTML(product.id)}</dd></div></dl>
          <div class="order-area">${order}</div><p class="direct-note">The independent seller arranges delivery and collects payment directly.</p>
        </div>
      </section>`;
  }

  function policyPage() {
    return `<section class="page-intro"><p class="eyebrow">CLEAR AND SIMPLE</p><h1>FINDS <span>POLICY</span></h1><p>Prototype information for arranging an order with an independent seller.</p></section>
      <div class="policy-grid">
        <article class="policy-card"><span>01</span><h2>SHIPPING</h2><p>Each seller arranges delivery directly with the buyer. Confirm the delivery area, timing and any delivery fee before ordering.</p></article>
        <article class="policy-card"><span>02</span><h2>PAYMENT</h2><p>Payment is collected directly by the seller. Finds does not process payments or provide checkout.</p></article>
        <article class="policy-card"><span>03</span><h2>COMPLAINTS</h2><p>For questions or complaints, email ${escapeHTML(data.policyEmail || '[email]')}.</p></article>
      </div>`;
  }

  function settingsPage() {
    return `<section class="page-intro settings-intro"><p class="eyebrow">A LITTLE SPACE FOR LATER</p><h1>SETTINGS<span>.</span></h1><p>Nothing to adjust just yet. This is a placeholder for future preferences.</p><div class="settings-spark" aria-hidden="true">✦</div></section>`;
  }

  function notFound() {
    return `<section class="page-intro"><p class="eyebrow">WELL, THIS IS AWKWARD</p><h1>THAT FIND <span>GOT AWAY</span></h1><p>We couldn’t find that page. Browse the shops and look for another one.</p><a class="order-button inline-button" href="#/shops">BROWSE SHOPS <span aria-hidden="true">↗</span></a></section>`;
  }

  function setActiveNav(route) {
    const activeRoute = route.startsWith('shop') || route === 'shops' ? 'shops' : route;
    document.querySelectorAll('[data-nav]').forEach(link => {
      const active = link.dataset.nav === activeRoute;
      link.classList.toggle('active', active);
      if (active) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
  }

  function closeMenu() {
    menu.classList.remove('menu-open');
    menu.setAttribute('aria-hidden', String(!window.matchMedia('(min-width: 1025px)').matches));
    scrim.hidden = true;
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation');
    document.body.classList.remove('menu-visible');
  }

  let renderedOnce = false;

  function revealPageContent() {
    const elements = [...root.querySelectorAll('.section-heading, .page-intro, .shop-card, .product-card, .store-cover-wrap, .store-heading, .store-products-head, .product-detail, .policy-card, .store-contact')];
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) {
      elements.forEach(element => element.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -24px 0px' });
    elements.forEach((element, index) => {
      element.classList.add('reveal-on-scroll');
      element.style.setProperty('--reveal-delay', `${(index % 8) * 60}ms`);
      observer.observe(element);
    });
  }

  function render() {
    const parts = location.hash.replace(/^#\/?/, '').split('/').map(part => {
      try { return decodeURIComponent(part); } catch { return part; }
    });
    const route = parts[0] || 'home';
    const id = parts[1] || '';
    const page = route === 'home' ? homePage()
      : route === 'shops' ? shopsPage()
      : route === 'shop' ? shopPage(id)
      : route === 'style' ? stylePage(id)
      : route === 'product' ? productPage(id)
      : route === 'policy' ? policyPage()
      : route === 'settings' ? settingsPage()
      : notFound();
    root.innerHTML = page;
    document.body.classList.toggle('home-view', route === 'home');
    setActiveNav(route);
    closeMenu();
    window.scrollTo(0, 0);
    revealPageContent();
    if (renderedOnce) {
      document.body.classList.remove('route-changing');
      void root.offsetWidth;
      document.body.classList.add('route-changing');
      window.setTimeout(() => document.body.classList.remove('route-changing'), 370);
    }
    renderedOnce = true;
    document.title = `${route === 'home' ? 'finds' : route === 'product' ? (data.products.find(item => item.id === id)?.name || 'finds') : route.charAt(0).toUpperCase() + route.slice(1)} — finds`;
  }

  function applyTheme(theme, persist = false) {
    const activeTheme = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = activeTheme;
    if (themeMeta) themeMeta.content = activeTheme === 'light' ? '#F1EBDD' : '#1F2226';
    if (themeButton) {
      const nextTheme = activeTheme === 'dark' ? 'light' : 'dark';
      themeButton.querySelector('.theme-toggle-label').textContent = `${nextTheme.toUpperCase()} MODE`;
      themeButton.querySelector('.theme-toggle-icon').textContent = activeTheme === 'dark' ? '☀' : '☾';
      themeButton.setAttribute('aria-pressed', String(activeTheme === 'light'));
      themeButton.setAttribute('aria-label', `Switch to ${nextTheme} mode`);
    }
    if (persist) {
      try { localStorage.setItem('finds-theme', activeTheme); } catch {}
    }
  }

  function applySidebarCollapse(collapsed, persist = false) {
    const isCollapsed = Boolean(collapsed);
    if (isCollapsed) document.documentElement.dataset.sidebarCollapsed = 'true';
    else delete document.documentElement.dataset.sidebarCollapsed;
    if (sidebarToggle) {
      sidebarToggle.setAttribute('aria-expanded', String(!isCollapsed));
      sidebarToggle.setAttribute('aria-label', isCollapsed ? 'Expand sidebar' : 'Collapse sidebar');
      sidebarToggle.title = isCollapsed ? 'Expand sidebar' : 'Collapse sidebar';
      sidebarToggle.querySelector('span').textContent = isCollapsed ? '›' : '‹';
    }
    if (persist) {
      try { localStorage.setItem('finds-sidebar-collapsed', String(isCollapsed)); } catch {}
    }
  }

  function fillTicker() {
    const track = document.getElementById('announcement-track');
    if (!track) return;
    const groups = track.querySelectorAll('.announcement-group');
    if (groups.length < 2) return;
    const first = groups[0];
    const second = groups[1];
    const sequence = tickerPhrases.map(phrase => `${phrase} ✦ `).join('');
    const markup = tickerPhrases.map(phrase => `${escapeHTML(phrase)} <span class="ticker-star" aria-hidden="true">✦</span> `).join('');
    first.innerHTML = markup;
    first.setAttribute('aria-label', sequence);
    let repeats = 1;
    const viewportWidth = track.parentElement.getBoundingClientRect().width;
    while (first.scrollWidth < viewportWidth && repeats < 64) {
      first.insertAdjacentHTML('beforeend', markup);
      repeats += 1;
    }
    second.innerHTML = first.innerHTML;
    second.setAttribute('aria-hidden', 'true');
  }

  themeButton.addEventListener('click', () => {
    applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark', true);
  });
  applyTheme(document.documentElement.dataset.theme, false);
  applySidebarCollapse(document.documentElement.dataset.sidebarCollapsed === 'true', false);
  fillTicker();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fillTicker);
  window.addEventListener('resize', fillTicker);

  menuToggle.addEventListener('click', () => {
    const open = !menu.classList.contains('menu-open');
    menu.classList.toggle('menu-open', open);
    menu.setAttribute('aria-hidden', String(!open));
    scrim.hidden = !open;
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    document.body.classList.toggle('menu-visible', open);
  });
  sidebarToggle.addEventListener('click', () => {
    applySidebarCollapse(document.documentElement.dataset.sidebarCollapsed !== 'true', true);
  });
  drawerClose.addEventListener('click', closeMenu);
  scrim.addEventListener('click', closeMenu);
  menu.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
  window.addEventListener('resize', closeMenu);
  window.addEventListener('hashchange', render);

  document.addEventListener('pointerdown', event => {
    const track = event.target.closest && event.target.closest('#style-track');
    if (!track || event.pointerType !== 'mouse') return;
    track.dataset.dragStart = event.clientX;
    track.dataset.scrollStart = track.scrollLeft;
    track.dataset.didDrag = 'false';
    track.setPointerCapture(event.pointerId);
  });
  document.addEventListener('pointermove', event => {
    const track = event.target.closest && event.target.closest('#style-track');
    if (!track || !track.hasPointerCapture(event.pointerId) || track.dataset.dragStart === undefined) return;
    const delta = event.clientX - Number(track.dataset.dragStart);
    if (Math.abs(delta) > 5) track.dataset.didDrag = 'true';
    track.scrollLeft = Number(track.dataset.scrollStart) - delta;
  });
  document.addEventListener('pointerup', event => {
    const track = event.target.closest && event.target.closest('#style-track');
    if (track && track.hasPointerCapture(event.pointerId)) {
      if (track.dataset.didDrag === 'true') track.dataset.suppressClickUntil = String(Date.now() + 350);
      delete track.dataset.dragStart;
      delete track.dataset.scrollStart;
      delete track.dataset.didDrag;
    }
  });
  document.addEventListener('click', event => {
    const track = event.target.closest && event.target.closest('#style-track');
    if (track && Number(track.dataset.suppressClickUntil || 0) > Date.now()) {
      event.preventDefault();
      event.stopPropagation();
      delete track.dataset.suppressClickUntil;
    }
  }, true);

  function updateHeroParallax() {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const mobile = window.matchMedia('(max-width: 760px)').matches;
    const offset = reduceMotion || mobile ? 0 : Math.max(-12, Math.min(12, window.scrollY * 0.035));
    document.documentElement.style.setProperty('--hero-parallax', `${offset}px`);
  }
  window.addEventListener('scroll', updateHeroParallax, { passive: true });
  window.addEventListener('resize', updateHeroParallax);
  updateHeroParallax();

  render();
})();
